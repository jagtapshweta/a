export type User = {
    ID: string;
    password: string;
    role: string;
    name:string;
};
  