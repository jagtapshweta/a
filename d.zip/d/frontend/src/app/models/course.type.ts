export type Course={
    course_id:string;
    title:string;
    credits:number;
    dept_name:string;
}