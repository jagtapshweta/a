export type Classroom={
    building:string;
    room_number:string;
    capacity:number;
}