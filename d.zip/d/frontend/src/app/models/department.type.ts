export type Department = {
    dept_name:string;
    building:string;
    budget:number;
};
  