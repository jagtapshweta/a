import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { StudentDashboardComponent } from './components/student-dashboard/student-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { FacultyDashboardComponent } from './components/faculty-dashboard/faculty-dashboard.component';
import { DepartmentHeadDashboardComponent } from './components/department-head-dashboard/department-head-dashboard.component';
import { RegistrarDashboardComponent } from './components/registrar-dashboard/registrar-dashboard.component';
import { StudentProfileComponent } from './components/student-profile/student-profile.component';


export const routes: Routes = [
    {
        path:'',
        pathMatch:'full',
        component:HomeComponent
    },
    // {
    //     path:'student-dashboard',
    //     component:StudentDashboardComponent,
    //     children:[
    //         {
    //             path:'profile',
    //             component:StudentProfileComponent
    //         }
    //     ]
    // },
    {
        path:'admin-dashboard',
        component:AdminDashboardComponent
    },
    {
        path:'faculty-dashboard',
        component:FacultyDashboardComponent
    },
    {
        path:'department-head-dashboard',
        component:DepartmentHeadDashboardComponent
    },
    {
        path:'registrar-dashboard',
        component:RegistrarDashboardComponent
    }
];
