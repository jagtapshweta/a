import { Component, OnInit } from '@angular/core';
import { MisService } from '../../services/mis.service';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [NgFor,NgIf],
  templateUrl: './student-profile.component.html',
  styleUrl: './student-profile.component.css'
})
export class StudentProfileComponent implements OnInit {

  students: any[] = [];
  isLoading: boolean = true; 

  constructor(private studentService: MisService) { }

  ngOnInit(): void {
    // this.studentService.getStudentsById(this.studentService.getUserId()).subscribe(
    //   data => {
    //     data=Array(data)
    //     this.students= data; 
    //     this.isLoading = false; 
    //   },
    //   error => {
    //     console.error('Error fetching student data:', error);
    //     this.isLoading = false;
    //   }
    // );
  }

}

