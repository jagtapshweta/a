// import { Component, inject, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { AdminService } from '../../../services/admin.service';
// import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { MisService } from '../../../services/mis.service';
// import { catchError } from 'rxjs/operators';
// import { throwError } from 'rxjs';
// import { Course } from '../../../models/course.type';

// @Component({
//   selector: 'app-manage-courses',
//   standalone: true,
//   imports: [CommonModule,ReactiveFormsModule],
//   templateUrl: './manage-courses.component.html',
//   styleUrls: ['./manage-courses.component.css']
// })
// export class ManageCoursesComponent {
//   courseForm!: FormGroup;
//   courses:Course[] = [];
//   editingCourse:Course | null = null;

//   adminService = inject(AdminService);
//   misService = inject(MisService);
  

//   constructor(private fb: FormBuilder) {
//     this.courseForm = this.fb.group({
//       dept_name: ['', Validators.required],
//       title: ['', Validators.required],
//       credits: ['', [Validators.required, Validators.min(1)]],
//       course_id:['', Validators.required],
//       prerequisites: this.fb.array([])
//     });
//   }

//   get prerequisites(): FormArray {
//     return this.courseForm.get('prerequisites') as FormArray;
//   }

//   addPrerequisite(): void {
//     this.prerequisites.push(this.fb.control('', Validators.required));
//   }

//   removePrerequisite(index: number): void {
//     this.prerequisites.removeAt(index);
//   }

//   get credits(){
//     return this.courseForm.get('credits');
//   }

//   get dept_name(){
//     return this.courseForm.get('dept_name');
//   }

//   get title(){
//     return this.courseForm.get('title');
//   }

//   get course_id(){
//     return this.courseForm.get('course_id')
//   }

  

//   ngOnInit(): void {
//     this.featchCourses()
//   }

//   featchCourses(){
//     this.adminService.getCourses().subscribe({
//       next: (data: any) => {
//         console.log('Fetched Users:', data);
//         this.courses = data;
//       },
//       error: (err) => {
//         console.error('Error fetching users:', err);
//       }
//     });
//   }

//   addOrUpdateCourse(): void {
//     if (this.courseForm.valid) {
//       const course:Course = {
//         dept_name: this.courseForm.value.dept_name,
//         credits: this.courseForm.value.credits,
//         title: this.courseForm.value.title,
//         course_id:this.courseForm.value.course_id 
//       };

//       const prereq:any []=this.courseForm.value.prerequisites
//       console.log(prereq)
//       if (this.editingCourse) {
//         if(prereq.length){
//           this.adminService.updatePrerequisites(this.editingCourse.course_id,prereq).pipe(
//             catchError((err) => {
//               console.error('prerequisites creation failed:', err);
//               return throwError(() => err);
//             })
//           )
//           .subscribe(() => {
//           });
//         }
//         this.adminService.updateCourse(this.editingCourse.course_id, course).pipe(
//           catchError((err) => {
//             console.error('Course update failed:', err);
//             alert('Course update failed. Please try again.');
//             return throwError(() => err);
//           })
//         )
//         .subscribe(() => {
//           alert('cousre updated successfully!');
//           this.resetForm();
//           this.featchCourses(); 
//         });

//       } else {
//         if(prereq.length){
//           this.adminService.addPrerequisites(course.course_id,prereq).pipe(
//             catchError((err) => {
//               console.error('prerequisites creation failed:', err);
//               return throwError(() => err);
//             })
//           )
//           .subscribe(() => {
//           });
//         }
//         this.adminService.addCourse(course).pipe(
//           catchError((err) => {
//             console.error('course creation failed:', err);
//             alert('Course creation failed. Please try again.');
//             return throwError(() => err);
//           })
//         )
//         .subscribe(() => {
//           alert('Course added successfully!');
//           this.resetForm();
//           this.featchCourses(); // Refresh users list
//         });
//       }
//     } else {
//       alert('Please fill the form correctly.');
//     }
//     this.courseForm.reset(); 
//   }

//   resetForm(): void {
//     this.courseForm.reset();
//     this.editingCourse = null;
//   }

//   // Edit a department
//   editCourse(course:Course): void {
//     this.editingCourse= course;

//     this.courseForm.patchValue({
//         dept_name: course.dept_name,
//         credits: course.credits,
//         title: course.title,
//         course_id:course.course_id 
//     });
//   }


//   // Delete a department
//   deleteCourse(course_id: string): void {

//       if (confirm("Are you sure you want to delete this user?")) {
//         this.adminService.deleteCourse(course_id).pipe(
//           catchError((err) => {
//             console.error('course deletion failed:', err);
//             alert('Course deletion failed. Please try again.');
//             return throwError(() => err);
//           })
//         )
//         .subscribe(() => {
//           alert('Course deleted successfully!');
//           this.featchCourses(); // Refresh users list
//         });
//       }
//   }

//   addPres():void{

//   }
  
// }

import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../services/admin.service';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MisService } from '../../../services/mis.service';
import { catchError, switchMap } from 'rxjs/operators';
import { throwError, of } from 'rxjs';
import { Course } from '../../../models/course.type';

@Component({
  selector: 'app-manage-courses',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './manage-courses.component.html',
  styleUrls: ['./manage-courses.component.css']
})
export class ManageCoursesComponent implements OnInit {
  courseForm!: FormGroup;
  courses: Course[] = [];
  editingCourse: Course | null = null;

  adminService = inject(AdminService);
  misService = inject(MisService);

  constructor(private fb: FormBuilder) {
    this.courseForm = this.fb.group({
      dept_name: ['', Validators.required],
      title: ['', Validators.required],
      credits: ['', [Validators.required, Validators.min(1)]],
      course_id: ['', Validators.required],
      prerequisites: this.fb.array([]),
    });
  }

  ngOnInit(): void {
    this.fetchCourses();
  }

  get prerequisites(): FormArray {
    return this.courseForm.get('prerequisites') as FormArray;
  }

  addPrerequisite(): void {
    this.prerequisites.push(this.fb.control('', Validators.required));
  }

  removePrerequisite(index: number): void {
    this.prerequisites.removeAt(index);
  }

  fetchCourses(): void {
    this.adminService.getCourses().subscribe({
      next: (data: any) => {
        console.log('Fetched Courses:', data);
        this.courses = data;
      },
      error: (err) => {
        console.error('Error fetching courses:', err);
      }
    });
  }

  addOrUpdateCourse(): void {
    if (this.courseForm.invalid) {
      alert('Please fill the form correctly.');
      return;
    }

    const course: Course = {
      dept_name: this.courseForm.value.dept_name,
      credits: this.courseForm.value.credits,
      title: this.courseForm.value.title,
      course_id: this.courseForm.value.course_id
    };

    const prereq: string[] = this.courseForm.value.prerequisites;

    if (this.editingCourse) {
      // Updating an existing course
      this.adminService.updateCourse(this.editingCourse.course_id, course).pipe(
        switchMap(() => {
          if (prereq.length) {
            return this.adminService.updatePrerequisites(course.course_id, prereq);
          }
          return of(null);
        }),
        catchError((err) => {
          console.error('Update failed:', err);
          alert('Update failed. Please try again.');
          return throwError(() => err);
        })
      ).subscribe(() => {
        alert('Course updated successfully!');
        this.resetForm();
        this.fetchCourses();
      });

    } else {
      // Adding a new course
      this.adminService.addCourse(course).pipe(
        switchMap(() => {
          if (prereq.length) {
            return this.adminService.addPrerequisites(course.course_id, prereq);
          }
          return of(null);
        }),
        catchError((err) => {
          console.error('Course creation failed:', err);
          alert('Course creation failed. Please try again.');
          return throwError(() => err);
        })
      ).subscribe(() => {
        alert('Course added successfully!');
        this.resetForm();
        this.fetchCourses();
      });
    }
  }

  resetForm(): void {
    this.courseForm.reset();
    this.prerequisites.clear();
    this.editingCourse = null;
  }

  editCourse(course: Course): void {
    this.editingCourse = course;
    this.courseForm.patchValue({
      dept_name: course.dept_name,
      credits: course.credits,
      title: course.title,
      course_id: course.course_id
    });

    // Fetch existing prerequisites and populate the form
    this.adminService.getPrerequisites(course.course_id).subscribe((prereqs: string[]) => {
      this.prerequisites.clear();
      prereqs.forEach((p) => this.prerequisites.push(this.fb.control(p, Validators.required)));
    });
  }

  deleteCourse(course_id: string): void {
    if (confirm("Are you sure you want to delete this course?")) {
      this.adminService.deleteCourse(course_id).pipe(
        catchError((err) => {
          console.error('Course deletion failed:', err);
          alert('Course deletion failed. Please try again.');
          return throwError(() => err);
        })
      ).subscribe(() => {
        alert('Course deleted successfully!');
        this.fetchCourses();
      });
    }
  }
}

