import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-enroll-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './enroll-student.component.html',
  styleUrls: ['./enroll-student.component.css']
})
export class EnrollStudentComponent {
  students = [
    { id: 'S101', name: 'Alice Johnson' },
    { id: 'S102', name: 'Bob Smith' },
    { id: 'S103', name: 'Charlie Brown' }
  ];

  courses = [
    { id: 'CS101', title: 'Data Structures' },
    { id: 'CS102', title: 'Algorithms' },
    { id: 'CS103', title: 'Database Systems' }
  ];

  selectedStudent: string = '';
  selectedCourse: string = '';
  actionMessage: string = '';

  enrollStudent() {
    if (!this.selectedStudent || !this.selectedCourse) {
      this.actionMessage = 'Please select a student and a course!';
      return;
    }
    this.actionMessage = `✅ Student ${this.selectedStudent} enrolled in ${this.selectedCourse}.`;
  }

  removeEnrollment() {
    if (!this.selectedStudent || !this.selectedCourse) {
      this.actionMessage = 'Please select a student and a course!';
      return;
    }
    this.actionMessage = `❌ Student ${this.selectedStudent} removed from ${this.selectedCourse}.`;
  }
}
