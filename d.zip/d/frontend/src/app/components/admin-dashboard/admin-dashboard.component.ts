import { Component } from '@angular/core';
import {CommonModule } from '@angular/common';
import { ManageUsersComponent } from '../allAdmin/manage-users/manage-users.component';
import { ManageDepartmentsComponent } from '../allAdmin/manage-departments/manage-departments.component';
// import { ManageCoursesComponent } from '../allAdmin/manage-courses/manage-courses.component';
import { ManageSectionsComponent } from '../allAdmin/manage-sections/manage-sections.component';
import { ManageReportsComponent } from '../allAdmin/manage-reports/manage-reports.component';
import { ManageClassroomsComponent } from '../allAdmin/manage-classrooms/manage-classrooms.component';
import { StudentManagementComponent } from '../allAdmin/student-management/student-management.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone:true,
  imports: [
   CommonModule,
   ManageUsersComponent,
   ManageDepartmentsComponent,
  //  ManageCoursesComponent,
   ManageSectionsComponent,
   ManageReportsComponent,
   ManageClassroomsComponent,
   StudentManagementComponent
  ],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent {
  activeSection: string = 'users';

  setActiveSection(section: string) {
    this.activeSection = section;
  }
}
