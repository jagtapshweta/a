import {
  MatDivider,
  MatDividerModule
} from "./chunk-TSA5GSGI.js";
import "./chunk-ZDCXT3ED.js";
import "./chunk-BX6XHMDW.js";
import "./chunk-JELFK4NM.js";
import "./chunk-XXXPJ3DZ.js";
import "./chunk-UNTID7UN.js";
import "./chunk-WZZJOV5G.js";
import "./chunk-XZO76R2V.js";
import "./chunk-DHFOCCO5.js";
export {
  MatDivider,
  MatDividerModule
};
