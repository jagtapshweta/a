const express = require("express");
const router = express.Router();
const takesController = require("../controllers/takesController");

router.get("/takes", takesController.getAllTakes);
router.get("/takes/:ID/:courseId/:secId/:semester/:year", takesController.getTakesById);
router.post("/takes", takesController.createTakes);
router.put("/takes/:ID/:courseId/:secId/:semester/:year", takesController.updateTakes);
router.delete("/takes/:ID/:courseId/:secId/:semester/:year", takesController.deleteTakes);

module.exports = router;
