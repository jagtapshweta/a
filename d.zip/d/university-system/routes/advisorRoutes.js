const express = require("express");
const router = express.Router();
const advisorController = require("../controllers/advisorController");

router.get("/advisor", advisorController.getAllAdvisors);
router.get("/advisor/:sID/:iID", advisorController.getAdvisorById);
router.post("/advisor", advisorController.createAdvisor);
router.delete("/advisor/:sID/:iID", advisorController.deleteAdvisor);

module.exports = router;
