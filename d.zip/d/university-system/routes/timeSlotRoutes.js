const express = require("express");
const router = express.Router();
const timeSlotController = require("../controllers/timeSlotController");

router.get("/time-slot", timeSlotController.getAllTimeSlots);
router.get("/time-slot/:timeSlotId", timeSlotController.getTimeSlotById);
router.post("/time-slot", timeSlotController.createTimeSlot);
router.put("/time-slot/:timeSlotId", timeSlotController.updateTimeSlot);
router.delete("/time-slot/:timeSlotId", timeSlotController.deleteTimeSlot);

module.exports = router;
