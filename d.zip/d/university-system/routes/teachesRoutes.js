const express = require("express");
const router = express.Router();
const teachesController = require("../controllers/teachesController");

router.get("/teaches", teachesController.getAllTeaches);
router.get("/teaches/:ID/:courseId/:secId/:semester/:year", teachesController.getTeachesById);
router.post("/teaches", teachesController.createTeaches);
router.put("/teaches/:ID/:courseId/:secId/:semester/:year", teachesController.updateTeaches);
router.delete("/teaches/:ID/:courseId/:secId/:semester/:year", teachesController.deleteTeaches);

module.exports = router;

