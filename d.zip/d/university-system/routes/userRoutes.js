const express = require("express");
const router = express.Router();
const authController = require("../controllers/userController");

router.post("/register", authController.register);
router.post("/login", authController.login);
router.get("/",authController.users)
router.delete('/:ID',authController.deleteUserById)
router.put('/:ID',authController.updateUserById)
module.exports = router;
