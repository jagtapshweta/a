const express = require("express");
const router = express.Router();
const prereqController = require("../controllers/prereqController");

router.get("/", prereqController.getAllPrereqs);
router.get("/:courseId", prereqController.getPrereqByCourseId);
router.post("/:courseId", prereqController.createPrereqById);
router.put("/:courseId", prereqController.updatePrereqByCourseId);
router.delete("/prereq/:courseId/:prereqId", prereqController.deletePrereq);

module.exports = router;
