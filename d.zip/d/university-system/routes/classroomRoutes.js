const express = require("express");
const router = express.Router();
const classroomController = require("../controllers/classroomController");


router.get("/", classroomController.getAllClassrooms);

router.get("/:primary_keys", classroomController.getClassroomById);

router.post("/", classroomController.createClassroom);

router.put("/:primary_keys", classroomController.updateClassroom);

router.delete("/:primary_keys", classroomController.deleteClassroom);

module.exports = router;
