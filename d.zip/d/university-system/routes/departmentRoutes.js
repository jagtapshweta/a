const express = require("express");
const router = express.Router();
const departmentController = require("../controllers/departmentController");

router.get("/", departmentController.getAllDepartments);
router.post("/", departmentController.createDepartment);
router.put("/:dept_name", departmentController.updateDepartment);
router.delete("/:dept_name", departmentController.deleteDepartment);

module.exports = router;
