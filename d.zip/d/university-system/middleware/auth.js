const jwt = require("jsonwebtoken");


const authMiddleware = (allowedRoles = []) => {
  return (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "No token provided" });
    }

    const token = authHeader.split(" ")[1];

    jwt.verify(token, "code", (err, decoded) => {
      if (err) return res.status(403).json({ error: "Invalid token" });

      if (allowedRoles.length && !allowedRoles.includes(decoded.role)) {
        return res.status(403).json({ error: "Forbidden: Insufficient rights" });
      }

      req.user = decoded;
      next();
    });
  };
};

module.exports = authMiddleware;
