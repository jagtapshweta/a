const mysql = require("mysql2/promise"); // Use 'mysql2/promise' for async/await support

const db = mysql.createPool({  // Use createPool for better connection management
  host: "localhost",
  user: "root",
  password: "Shweta#26",
  database: "university",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

module.exports = { db };
