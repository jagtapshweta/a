const express = require('express');
const cors = require('cors');
const app = express();


app.use(express.json());
app.use(cors());

const userRoutes = require("./routes/userRoutes");
const classroomRoutes=require('./routes/classroomRoutes')
const departmentRoutes=require('./routes/departmentRoutes')
const courseRoutes=require('./routes/courseRoutes')
const instructorRoutes=require("./routes/instructorRoutes")
const sectionRoutes=require('./routes/sectionRoutes')
const teachesRoutes=require('./routes/teachesRoutes')
const studentRoutes = require("./routes/studentRoutes");
const takesRoutes=require('./routes/teachesRoutes')
const advisorRoutes=require('./routes/advisorRoutes')
const timeSlotRoutes=require('./routes/timeSlotRoutes')
const prereqRoutes=require('./routes/prereqRoutes')


app.use("/api/user", userRoutes);
app.use('/api/classroom',classroomRoutes)
app.use('/api/department',departmentRoutes)
app.use('/api/course',courseRoutes)
app.use('/api/instructor',instructorRoutes)
app.use('/api/section',sectionRoutes)
app.use('/api/teaches',teachesRoutes)
app.use('/api/student',studentRoutes)
app.use('/api/takes',takesRoutes)
app.use('/api/advisor',advisorRoutes)
app.use('/api/timeSlot',timeSlotRoutes)
app.use('/api/prereq',prereqRoutes)



const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
