const { db } = require("../config/db");

exports.getAllAdvisors = async (req, res) => {
  try {
    const [advisors] = await db.execute("SELECT * FROM advisor");
    res.json(advisors);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getAdvisorById = async (req, res) => {
  const { sID, iID } = req.params;
  try {
    const [advisor] = await db.execute(
      "SELECT * FROM advisor WHERE s_id = ? AND i_id = ?",
      [sID, iID]
    );
    if (advisor.length === 0) {
      return res.status(404).json({ message: "Advisor entry not found" });
    }
    res.json(advisor[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createAdvisor = async (req, res) => {
  const { sID, iID } = req.body;
  try {
    await db.execute(
      "INSERT INTO advisor (s_id, i_id) VALUES (?, ?)",
      [sID, iID]
    );
    res.status(201).json({ message: "Advisor entry created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteAdvisor = async (req, res) => {
  const { sID, iID } = req.params;
  try {
    const [result] = await db.execute(
      "DELETE FROM advisor WHERE s_id = ? AND i_id = ?",
      [sID, iID]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Advisor entry not found" });
    }
    res.json({ message: "Advisor entry deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
