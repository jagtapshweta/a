const { db } = require("../config/db");

// Get all classrooms
exports.getAllClassrooms = async (req, res) => {
  try {
    const [classrooms] = await db.query("SELECT * FROM classroom");
    res.json(classrooms);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get classroom by ID (building and room_number as composite key)
exports.getClassroomById = async (req, res) => {
  const { primary_keys } = req.params;

  // Correcting split syntax
  const [building, room_number] = primary_keys.split('&');

  try {
    const [classroom] = await db.query(
      "SELECT * FROM classroom WHERE building = ? AND room_number = ?",
      [building, room_number]
    );

    if (classroom.length === 0) {
      return res.status(404).json({ message: "Classroom not found" });
    }

    res.json(classroom[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Create a new classroom
exports.createClassroom = async (req, res) => {
  const { building, room_number, capacity } = req.body;
  
  try {
    await db.execute(
      "INSERT INTO classroom (building, room_number, capacity) VALUES (?, ?, ?)",
      [building, room_number, capacity]
    );
    
    res.status(201).json({ message: "Classroom created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Update a classroom by composite key (building & room_number)
exports.updateClassroom = async (req, res) => {
  const { primary_keys } = req.params;
  const [old_building, old_room_number] = primary_keys.split('&');
  const { building, room_number, capacity } = req.body;

  try {
    const [result] = await db.execute(
      "UPDATE classroom SET building = ?, room_number = ?, capacity = ? WHERE building = ? AND room_number = ?",
      [building, room_number, capacity, old_building, old_room_number]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Classroom not found" });
    }

    res.json({ message: "Classroom updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete a classroom by composite key (building & room_number)
exports.deleteClassroom = async (req, res) => {
  const { primary_keys } = req.params;
  const [building, room_number] = primary_keys.split('&');

  try {
    const [result] = await db.execute(
      "DELETE FROM classroom WHERE building = ? AND room_number = ?",
      [building, room_number]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Classroom not found" });
    }

    res.json({ message: "Classroom deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
