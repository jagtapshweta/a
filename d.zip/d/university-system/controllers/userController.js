const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {db}=require('../config/db')

exports.register = async (req, res) => {
  try {
    const { ID, password, role,name } = req.body;

    console.log(ID,password)
    if (!ID|| !password || !role ||!name) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const query = "INSERT INTO user (ID, password, role,name) VALUES (?, ?, ?,?)";
    await db.query(query, [ID, hashedPassword, role,name]);
    
    return res.json({meass:'added'})
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.users = async (req, res) => {
  try {
    const [allUsers] = await db.query('SELECT ID,name,role FROM user'); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: err.message });
  }
};

exports.updateUserById = async (req, res) => {
  const oldID=req.params.ID
  const { ID,password, role,name } = req.body;
  try {
    const [allUsers] = await db.query('UPDATE user SET ID=?, password=?,name=?,role=? WHERE ID=?',[ID,password,name,role,oldID]); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error updating users:', err);
    return res.status(500).json({ error: err.message });
  }
};

exports.deleteUserById=async (req,res)=>{
const {ID}=req.params

  try {
    const [allUsers] = await db.query('DELETE FROM user WHERE ID = ?',[ID]); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: err.message });
  }
}


exports.login = async (req, res) => {
  try {
    const { ID, password } = req.body;
    if (!ID || !password) {
      return res.status(400).json({ error: "Missing userId or password" });
    }
    
    const [results] = await db.query("SELECT ID, password, role, name FROM user WHERE ID = ?", [ID]); // Fixing the query execution
    
    if (results.length === 0) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = results[0];
    console.log("User found:", user);

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign(
      { ID: user.ID, role: user.role}, 
      "code", 
      { expiresIn: "1h" }
    );

    console.log("Generated Token:", token);

    res.json({
      message: "Login successful",
      token,
      user: {
        ID: user.ID,
        role: user.role,
        name: user.name,
      },
    });
  } catch (error) {

    console.log("Login error:", error);
    res.status(500).json({ error: "Server error" });
  }
};
