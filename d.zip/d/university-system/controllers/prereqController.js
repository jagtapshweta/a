const { db } = require("../config/db");

exports.getAllPrereqs = async (req, res) => {
  try {
    const [prereqs] = await db.execute("SELECT * FROM prereq");
    res.json(prereqs);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getPrereqByCourseId = async (req, res) => {
  const { courseId } = req.params;
  try {
    const [prereqs] = await db.query(
      "SELECT * FROM prereq WHERE course_id = ?",
      [courseId]
    );
    if (prereqs.length === 0) {
      return res.status(404).json({ message: "Prerequisites not found for this course" });
    }
    res.json(prereqs);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createPrereqById= async (req, res) => {
  const prerequisites = req.body;
  const {courseId} =req.params;

  console.log(prereq)
  try {
    for (const prereq of prerequisites) {
      await db.query("INSERT INTO prereq (course_id, prereq_id) VALUES (?, ?)", [courseId, prereq]);
    }
    res.status(201).json({ message: "Prerequisite added successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.createPrereq = async (req, res) => {
  const { courseId, prereqId } = req.body;
  try {
    await db.execute(
      "INSERT INTO prereq (course_id, prereq_id) VALUES (?, ?)",
      [courseId, prereqId]
    );
    res.status(201).json({ message: "Prerequisite added successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deletePrereq = async (req, res) => {
  const { courseId, prereqId } = req.params;
  try {
    const [result] = await db.execute(
      "DELETE FROM prereq WHERE course_id = ? AND prereq_id = ?",
      [courseId, prereqId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Prerequisite not found" });
    }
    res.json({ message: "Prerequisite deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.updatePrereqByCourseId=async (req, res) => {
  const  prerequisites  = req.body;
  const {courseId} =req.params;

  try {
    await db.query("DELETE FROM prereq WHERE course_id =?",[courseId]);
    for (const prereq of prerequisites) {
      console.log(prereq)
      await db.query("INSERT INTO prereq (course_id, prereq_id) VALUES (?, ?)", [courseId, prereq]);
    }
    res.status(201).json({ message: "Prerequisite added successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
