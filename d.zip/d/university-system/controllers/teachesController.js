const { db } = require("../config/db");

exports.getAllTeaches = async (req, res) => {
  try {
    const [teaches] = await db.execute("SELECT * FROM teaches");
    res.json(teaches);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getTeachesById = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  try {
    const [teach] = await db.execute(
      "SELECT * FROM teaches WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [ID, courseId, secId, semester, year]
    );
    if (teach.length === 0) {
      return res.status(404).json({ message: "Teaches entry not found" });
    }
    res.json(teach[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createTeaches = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.body;
  try {
    await db.execute(
      "INSERT INTO teaches (ID, course_id, sec_id, semester, year) VALUES (?, ?, ?, ?, ?)",
      [ID, courseId, secId, semester, year]
    );
    res.status(201).json({ message: "Teaches entry created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateTeaches = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  const { newSemester, newYear } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE teaches SET semester = ?, year = ? WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [newSemester, newYear, ID, courseId, secId, semester, year]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Teaches entry not found" });
    }
    res.json({ message: "Teaches entry updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteTeaches = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  try {
    const [result] = await db.execute(
      "DELETE FROM teaches WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [ID, courseId, secId, semester, year]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Teaches entry not found" });
    }
    res.json({ message: "Teaches entry deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
