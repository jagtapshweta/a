const { db } = require("../config/db");

exports.getAllTakes = async (req, res) => {
  try {
    const [takes] = await db.execute("SELECT * FROM takes");
    res.json(takes);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getTakesById = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  try {
    const [take] = await db.execute(
      "SELECT * FROM takes WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [ID, courseId, secId, semester, year]
    );
    if (take.length === 0) {
      return res.status(404).json({ message: "Takes entry not found" });
    }
    res.json(take[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createTakes = async (req, res) => {
  const { ID, courseId, secId, semester, year, grade } = req.body;
  try {
    await db.execute(
      "INSERT INTO takes (ID, course_id, sec_id, semester, year, grade) VALUES (?, ?, ?, ?, ?, ?)",
      [ID, courseId, secId, semester, year, grade]
    );
    res.status(201).json({ message: "Takes entry created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateTakes = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  const { newGrade } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE takes SET grade = ? WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [newGrade, ID, courseId, secId, semester, year]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Takes entry not found" });
    }
    res.json({ message: "Takes entry updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteTakes = async (req, res) => {
  const { ID, courseId, secId, semester, year } = req.params;
  try {
    const [result] = await db.execute(
      "DELETE FROM takes WHERE ID = ? AND course_id = ? AND sec_id = ? AND semester = ? AND year = ?",
      [ID, courseId, secId, semester, year]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Takes entry not found" });
    }
    res.json({ message: "Takes entry deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
