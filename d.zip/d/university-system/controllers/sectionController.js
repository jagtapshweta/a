const {db} = require("../config/db");

exports.getAllSections = async (req, res) => {
  try {
    const [sections] = await db.execute("SELECT * FROM section");
    res.json(sections);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getSectionById = async (req, res) => {
  const sectionId = req.params.id;
  try {
    const [section] = await db.execute("SELECT * FROM section WHERE course_id = ? AND sec_id = ?", [sectionId.split("-")[0], sectionId.split("-")[1]]);
    if (section.length === 0) {
      return res.status(404).json({ message: "Section not found" });
    }
    res.json(section[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createSection = async (req, res) => {
  const { courseId, secId, semester, year, building, roomNumber, timeSlotId } = req.body;
  try {
    await db.execute(
      "INSERT INTO section (course_id, sec_id, semester, year, building, room_number, time_slot_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [courseId, secId, semester, year, building, roomNumber, timeSlotId]
    );
    res.status(201).json({ message: "Section created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateSection = async (req, res) => {
  const sectionId = req.params.id;
  const { semester, year, building, roomNumber, timeSlotId } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE section SET semester = ?, year = ?, building = ?, room_number = ?, time_slot_id = ? WHERE course_id = ? AND sec_id = ?",
      [semester, year, building, roomNumber, timeSlotId, sectionId.split("-")[0], sectionId.split("-")[1]]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Section not found" });
    }
    res.json({ message: "Section updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteSection = async (req, res) => {
  const sectionId = req.params.id;
  try {
    const [result] = await db.execute("DELETE FROM section WHERE course_id = ? AND sec_id = ?", [sectionId.split("-")[0], sectionId.split("-")[1]]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Section not found" });
    }
    res.json({ message: "Section deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
