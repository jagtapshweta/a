const { db } = require("../config/db");

exports.getAllTimeSlots = async (req, res) => {
  try {
    const [timeSlots] = await db.execute("SELECT * FROM time_slot");
    res.json(timeSlots);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getTimeSlotById = async (req, res) => {
  const { timeSlotId } = req.params;
  try {
    const [timeSlot] = await db.execute(
      "SELECT * FROM time_slot WHERE time_slot_id = ?",
      [timeSlotId]
    );
    if (timeSlot.length === 0) {
      return res.status(404).json({ message: "Time slot not found" });
    }
    res.json(timeSlot[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createTimeSlot = async (req, res) => {
  const { timeSlotId, day, startTime, endTime } = req.body;
  try {
    await db.execute(
      "INSERT INTO time_slot (time_slot_id, day, start_time, end_time) VALUES (?, ?, ?, ?)",
      [timeSlotId, day, startTime, endTime]
    );
    res.status(201).json({ message: "Time slot created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateTimeSlot = async (req, res) => {
  const { timeSlotId } = req.params;
  const { day, startTime, endTime } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE time_slot SET day = ?, start_time = ?, end_time = ? WHERE time_slot_id = ?",
      [day, startTime, endTime, timeSlotId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Time slot not found" });
    }
    res.json({ message: "Time slot updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteTimeSlot = async (req, res) => {
  const { timeSlotId } = req.params;
  try {
    const [result] = await db.execute(
      "DELETE FROM time_slot WHERE time_slot_id = ?",
      [timeSlotId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Time slot not found" });
    }
    res.json({ message: "Time slot deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
