const db = require("../config/db");

exports.getAllInstructors = async (req, res) => {
  try {
    const [instructors] = await db.execute("SELECT * FROM instructor");
    res.json(instructors);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getInstructorById = async (req, res) => {
  const instructorId = req.params.id;
  try {
    const [instructor] = await db.execute("SELECT * FROM instructor WHERE ID = ?", [instructorId]);
    if (instructor.length === 0) {
      return res.status(404).json({ message: "Instructor not found" });
    }
    res.json(instructor[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};


exports.createInstructor = async (req, res) => {
  const { ID, name, deptName, salary } = req.body;
  try {
    await db.execute(
      "INSERT INTO instructor (ID, name, dept_name, salary) VALUES (?, ?, ?, ?)",
      [ID, name, deptName, salary]
    );
    res.status(201).json({ message: "Instructor created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateInstructor = async (req, res) => {
  const instructorId = req.params.id;
  const { name, deptName, salary } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE instructor SET name = ?, dept_name = ?, salary = ? WHERE ID = ?",
      [name, deptName, salary, instructorId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Instructor not found" });
    }
    res.json({ message: "Instructor updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteInstructor = async (req, res) => {
  const instructorId = req.params.id;
  try {
    const [result] = await db.execute("DELETE FROM instructor WHERE ID = ?", [instructorId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Instructor not found" });
    }
    res.json({ message: "Instructor deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
