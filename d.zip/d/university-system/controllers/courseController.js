const {db} = require("../config/db");

exports.getAllCourses = async (req, res) => {
  try {
    const [courses] = await db.query("SELECT * FROM course");
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getCourseById = async (req, res) => {
  const courseId = req.params.id;
  try {
    const [course] = await db.query("SELECT * FROM course WHERE course_id = ?", [courseId]);
    if (course.length === 0) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json(course[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createCourse = async (req, res) => {
  const { course_id, title, dept_name, credits } = req.body;
  try {
    await db.execute(
      "INSERT INTO course (course_id, title, dept_name, credits) VALUES (?, ?, ?, ?)",
      [course_id, title, dept_name, credits]
    );

    
    res.status(201).json({ message: "Course created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateCourse = async (req, res) => {
  const old_course_id = req.params.id;
  const {course_id, title, dept_name, credits } = req.body;
  try {
    const [result] = await db.query(
      "UPDATE course SET title = ?, dept_name = ?, credits = ? WHERE course_id = ?",
      [title, dept_name, credits, old_course_id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json({ message: "Course updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteCourse = async (req, res) => {
  const courseId = req.params.id;
  try {
    const [result] = await db.execute("DELETE FROM course WHERE course_id = ?", [courseId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json({ message: "Course deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
