const {db }= require("../config/db");

exports.getAllStudents = async (req, res) => {
  try {
    const [students] = await db.execute("SELECT * FROM student");
    res.json(students);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getStudentById = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.query("SELECT * FROM student WHERE ID = ?", [id]); // No need for .promise() now

    if (!Array.isArray(rows)) {
      return res.status(500).json({ error: "Database error: Unexpected response format" });
    }

    if (rows.length === 0) {
      return res.status(404).json({ error: "Student not found" });
    }

    console.log(rows);
    res.json(rows[0]); // Send only the first student object
  } catch (error) {
    console.error("Database Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};




exports.createStudent = async (req, res) => {
  try {

    const { ID,name,dept_name,tot_cred } = req.body;
    console.log(req.body)
    const [result] = await db.execute(
      "INSERT INTO student ( ID,name,dept_name,tot_cred ) VALUES (?, ?, ?, ?)",
      [ID,name,dept_name,tot_cred]
    );

    if (result.affectedRows === 0) {
      return res.status(400).json({ error: "Failed to create student" });
    }

    res.status(201).json({ message: "Student created successfully" });
  } catch (error) {
    console.log(error);
    res.status(400).json({ error: error.message });
  }
};

exports.updateStudent = async (req, res) => {
  try {
    const { name, email, department, rollNumber } = req.body;
    const { id } = req.params;

    const [result] = await db.execute(
      "UPDATE student SET name = ?, email = ?, department = ?, roll_number = ? WHERE id = ?",
      [name, email, department, rollNumber, id]
    );

    if (result.affectedRows === 0) return res.status(404).json({ error: "Student not found" });

    res.json({ message: "Student updated successfully" });
  } catch (error) {
    console.log(error);
    res.status(400).json({ error: error.message });
  }
};

exports.deleteStudent = async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.execute("DELETE FROM student WHERE id = ?", [id]);

    if (result.affectedRows === 0) return res.status(404).json({ error: "Student not found" });

    res.json({ message: "Student deleted successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
