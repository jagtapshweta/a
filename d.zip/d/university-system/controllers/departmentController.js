const {db} = require("../config/db");

exports.getAllDepartments = async (req, res) => {
  try {
    const [departments] = await db.execute("SELECT * FROM department");
    res.json(departments);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.getDepartmentById = async (req, res) => {
  const departmentId = req.params.id;
  try {
    const [department] = await db.execute(
      "SELECT * FROM department WHERE id = ?",
      [departmentId]
    );
    if (department.length === 0) {
      return res.status(404).json({ message: "Department not found" });
    }
    res.json(department[0]);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.createDepartment = async (req, res) => {
  const { dept_name, building, budget } = req.body;
  try {
    await db.query(
      "INSERT INTO department (dept_name, building, budget) VALUES (?, ?, ?)",
      [dept_name, building, budget]
    );
    res.status(201).json({ message: "Department created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.updateDepartment = async (req, res) => {
  const old_dept_name = req.params.dept_name;
  const { dept_name, building, budget } = req.body;
  try {
    const [result] = await db.execute(
      "UPDATE department SET dept_name = ?, building = ?, budget = ? WHERE dept_name = ?",
      [dept_name, building, budget, old_dept_name]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Department not found" });
    }
    res.json({ message: "Department updated successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteDepartment = async (req, res) => {
  const dept_name = req.params.dept_name;
  try {
    const [result] = await db.query(
      "DELETE FROM department WHERE dept_name = ?",
      [dept_name]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Department not found" });
    }
    res.json({ message: "Department deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};
