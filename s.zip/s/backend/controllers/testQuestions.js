const {db}=require('../config/db')


exports.getQuestions = async (req, res) => {
    const { testId } = req.params;

    try {
        console.log("hii")
        const [ans]=await db.query('select * from test_questions WHERE test_id=?',[testId])

        console.log(ans)
        const sqlQuery = `
            SELECT q.* FROM questions q
            JOIN test_questions tq ON q.id = tq.question_id
            WHERE tq.test_id = ?;
        `;

        const [result]=await db.query(sqlQuery, [testId])
               
      
        res.json(result); // Send fetched questions as JSON
        

    } catch (error) {
        res.status(500).json({ error: 'Server error', details: error.message });
    }
};

