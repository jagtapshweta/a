const {db}=require('../config/db')


exports.getCoursesByStudentId = async (req, res) => {
    const { id } = req.params;

    try {
        console.log(req.params)
        const sqlQuery = `
            SELECT * FROM takes
            WHERE id=?
        `;

        const [results]=await db.query(sqlQuery, [id]); 

        return res.json(results)

    } catch (error) {
        res.status(500).json({ error: 'Server error', details: error.message });
    }
};

