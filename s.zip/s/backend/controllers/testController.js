const { db } = require('../config/db')
const { v4: uuidv4 } = require('uuid');

exports.createTest = async (req, res) => {
    try {
        const { course_id, title, teacher_id, time_limit, number_of_questions, end_at } = req.body;
        const testId = uuidv4();

        console.log(req.body);

        // Insert the test into the `tests` table
        const testQuery = `
            INSERT INTO tests (id, title, course_id, teacher_id, time_limit, number_of_questions, end_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        await db.query(testQuery, [testId, title, course_id, teacher_id, time_limit, number_of_questions, end_at]);

        // Fetch `number_of_questions` random questions for the given course
        const questionQuery = `
            SELECT id FROM questions 
            WHERE course_id = ? 
            ORDER BY RAND() 
            LIMIT ?
        `;
        const [questions] = await db.query(questionQuery, [course_id, number_of_questions]);

        if (questions.length === 0) {
            return res.status(400).json({ error: 'No questions available for this course' });
        }

        const testQuestionQuery = `
            INSERT INTO test_questions (test_id, question_id) VALUES ?
        `;
        const testQuestionValues = questions.map(q => [testId, q.id]);

        await db.query(testQuestionQuery, [testQuestionValues]);

        res.status(201).json({ message: 'Test created successfully with questions' });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to create test' });
    }
};


exports.getAllTests=async(req,res)=>{
    try {
      
        const [tests]=await db.query("select * from tests");

        res.status(200).json(tests)
        
    } catch (error) {
        res.json({err:error.message})
    }
}
