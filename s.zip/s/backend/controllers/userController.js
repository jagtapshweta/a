const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {db}=require('../config/db');

exports.register = async (req, res) => {
  try {
    const { id, password, role,name } = req.body;

    console.log(req.body)
    if (!id|| !password || !role ||!name) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const query = "INSERT INTO users (id, password, role,name) VALUES (?, ?, ?,?)";
    await db.query(query, [id, hashedPassword, role,name]);
    
    return res.json({meass:'added'})
  } catch (error) {
    console.log(error.message)
    res.status(500).json({ error: error.message });
  }
};

exports.users = async (req, res) => {
  try {
    const [allUsers] = await db.query('SELECT id,name,role FROM users'); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: err.message });
  }
};


exports.getById = async (req, res) => {
  try {
    const {userId}=res.params

    const [allUsers] = await db.query('SELECT id,name,role FROM users where id=?',[userId]); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: err.message });
  }
};

exports.updateUserById = async (req, res) => {
  const oldID=req.params.id
  const { id,password, role,name } = req.body;
  try {
    const [allUsers] = await db.query('UPDATE users SET id=?, password=?,name=?,role=? WHERE ID=?',[id,password,name,role,oldID]); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error updating users:', err);
    return res.status(500).json({ error: err.message });
  }
};

exports.deleteUserById=async (req,res)=>{
const {id}=req.params

  try {
    const [allUsers] = await db.query('DELETE FROM users WHERE id = ?',[id]); 
    return res.status(200).json(allUsers);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: err.message });
  }
}


exports.login = async (req, res) => {
  try {
    const { id, password } = req.body;
    if (!id || !password) {
      return res.status(400).json({ error: "Missing userId or password" });
    }
    
    const [results] = await db.query("SELECT id, password, role, name FROM users WHERE ID = ?", [id]); // Fixing the query execution
    
    if (results.length === 0) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = results[0];
    console.log("User found:", user);

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role}, 
      "code", 
      { expiresIn: "1h" }
    );

    console.log("Generated Token:", token);

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        role: user.role,
        name: user.name,
      },
    });
  } catch (error) {

    console.log("Login error:", error);
    res.status(500).json({ error: "Server error" });
  }
};
