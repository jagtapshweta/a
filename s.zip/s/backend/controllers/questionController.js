const { db } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

exports.addQuestion = async (req, res) => {
    try {
        const questionData = req.body;

        console.log("Received Data:", req.body);
        console.log("hii")

        const questionId = uuidv4(); // Generate a unique question ID
        const { course_id, question, options, correct_options, math_expression, image } = questionData;

        // Check if all required fields are present in the request body
        if (!course_id || !question || !options || !correct_options) {
            return res.status(400).json({ error: "Missing required fields" });
        }

        // Insert the question into the database
        await db.query(
            "INSERT INTO questions (id, course_id, question, options, correct_options, math_expression, image) VALUES (?,?,?,?,?,?,?)",
            [
                questionId,
                course_id,
                question,
                JSON.stringify(options), // Convert options to JSON string
                JSON.stringify(correct_options), // Convert correct_options to JSON string
                math_expression,
                image
            ]
        );

        // Send a success response
        return res.json({ message: 'Question added successfully' });

    } catch (error) {
        console.error("Error:", error.message); // Log the error for debugging
        res.status(500).json({ error: error.message });
    }
};
