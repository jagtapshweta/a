const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {db}=require('../config/db');
const { use } = require("../routes/userRoutes");

exports.add=async (req, res) => {
    try {
        const { responses, totalScore } = req.body;
    
        // Assuming you're using a database connection, such as with mysql2 or pg
        const query = `
            INSERT INTO test_responses (test_id, student_id, question_id, options, score, submitted_at)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
    
        // Loop through each response and insert into the database
        responses.forEach(async (response) => {
            const { test_id, student_id, question_id, selected_option_key, score, submitted_at } = response;
            
            // Convert submitted_at to MySQL DATETIME format (YYYY-MM-DD HH:MM:SS)
            const submittedAtFormatted = new Date(submitted_at).toISOString().slice(0, 19).replace('T', ' ');
    
            // Prepare the options as JSON (assuming selected_option_key is a string, if you want an array, modify accordingly)
            const optionsJson = JSON.stringify({ selected_option: selected_option_key });
    
            try {
                await db.query(query, [test_id, student_id, question_id, optionsJson, score, submittedAtFormatted]);
            } catch (err) {
                console.error(`Error inserting response for question ${question_id}:`, err);
                return res.status(500).json({ error: 'Database insertion failed', details: err.message });
            }
        });
    
        console.log("hii")
        // Return the total score once all responses are processed
        res.json({ message: 'Test submitted successfully', totalScore });
    
    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Server error', details: error.message });
    }
    
};

exports.getTestsByUserId=async (req, res) => {
    try {
        const {userId } = req.params;
    
        const [result]=await db.query('SELECT * FROM test_responses WHERE student_id=?',[userId])

        res.json(result);
    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Server error', details: error.message });
    }
    
};


exports.getStudentsByTestId=async (req, res) => {
    try {
        const {testId } = req.params;
    
        const [result]=await db.query('SELECT * FROM test_responses WHERE test_id=?',[testId])

        res.json(result);
    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Server error', details: error.message });
    }
    
};
