const express = require('express');
const cors = require('cors');
require('dotenv').config();
const bodyParser = require('body-parser');

const app = express();
app.use(express.json());
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const userRoutes = require("./routes/userRoutes");
const questionRoutes = require("./routes/questionRoutes");
const testRoutes=require('./routes/testRoutes');
const tesQuesRoute=require('./routes/testQuestionsRoutes');
const courseRoute=require('./routes/courseRoute')
const resRoute=require('./routes/resRoutes')

app.use("/api/user", userRoutes);
app.use("/api/test",testRoutes)
app.use("/api/question", questionRoutes);
app.use('/api/testQuestions',tesQuesRoute);
app.use('/api/course',courseRoute)
app.use('/api/res',resRoute)


app.listen(process.env.PORT, () => {
    console.log(`Your server is running at http://localhost:${process.env.PORT}`);
});
