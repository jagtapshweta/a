const express = require("express");
const router = express.Router();
const quesController = require("../controllers/questionController");

router.post("/", quesController.addQuestion);

module.exports = router;
