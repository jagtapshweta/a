const express = require("express");
const router = express.Router();
const tstController = require("../controllers/testQuestions");


router.get("/:testId",tstController.getQuestions)

module.exports = router;
