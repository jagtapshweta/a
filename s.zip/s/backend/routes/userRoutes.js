const express = require("express");
const router = express.Router();
const authController = require("../controllers/userController");

router.post("/register", authController.register);
router.post("/login", authController.login);
router.get("/",authController.users)
router.delete('/:id',authController.deleteUserById)
router.put('/:id',authController.updateUserById)
router.get('/test/:userId',  authController.getById)

module.exports = router;
