const express = require("express");
const router = express.Router();
const tstController = require("../controllers/testController");

router.post("/", tstController.createTest);
router.get("/",tstController.getAllTests)
module.exports = router;
