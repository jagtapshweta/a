const express = require("express");
const router = express.Router();
const quesController = require("../controllers/resController");

router.post("/", quesController.add);
router.get("/:userId",quesController.getTestsByUserId)
router.get("/test/:testId",quesController.getStudentsByTestId)

module.exports = router;
