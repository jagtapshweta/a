import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { User } from '../../model/user.type';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  http=inject(HttpClient)

  constructor() { }

  login(user: User): Observable<any> {  
    return this.http.post<any>('http://localhost:5000/api/user/login', user);
  }

  getBaseUrl():string{
    return "http://localhost:5000/api";
  }

  getRole(userId: string): string {
    switch (userId.charAt(0)) {
      case 'A': return "Admin";
      case 'S': return "Student";
      case 'D': return "Department Head";
      case 'T': return "Teacher";
      case 'R': return "Registrar";
      default: return "Unknown Role"; 
    }
  }

  getToken():string{
    const token = JSON.parse(localStorage.getItem('token') || '{}'); 
    return token;
  }

  getUserId(): string {
    const user = JSON.parse(localStorage.getItem('user') || '{}'); 
    return user.id ? user.id :'';
  }

  getUserRole(): string {
    const user = JSON.parse(localStorage.getItem('user') || '{}'); 
    return user.role ? user.role :'';
  }

  getStudentById(userId:any): Observable<any> {  
    return this.http.get<any>('http://localhost:5000/api/user')
  }

  getUserName(): string {
    const user = JSON.parse(localStorage.getItem('user') || '{}'); 
    return user.name ? user.name.split(' ')[0] : '';
  }
  
}
