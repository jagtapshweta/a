import { HttpBackend, HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Question } from '../../model/question.type';

@Injectable({
  providedIn: 'root'
})
export class QuestionsService {
  http=inject(HttpClient)
  constructor() { }

  addQuestion(question:Question):Observable<any>{
    console.log(question)
    return this.http.post<any>('http://localhost:5000/api/question',question)
  }
}
