// tests.service.ts
import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class TestsService {
  private userService=inject(UserService)
  private apiUrl = 'http://localhost:5000/api/test'; 

  constructor(private http: HttpClient) {}

  dataToSend(data:any):any{
    return{
      ...data,
      teacher_id:this.userService.getUserId()
    };
  }

  createTest(testData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, this.dataToSend(testData));
  }

  getActiveTests():Observable<any>{
    return this.http.get(this.apiUrl)
  }

  getTestQuestions(testId:string): Observable<any> {
    console.log(testId)
    return this.http.get(`http://localhost:5000/api/testQuestions/${testId}`);
  }

  submitTestResponse(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/submit`, data);
  }
  
}
