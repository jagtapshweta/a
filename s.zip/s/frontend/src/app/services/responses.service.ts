import { HttpBackend, HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ResponsesService {

  http=inject(HttpClient)
  constructor() { }

  getTestsByUserId(userId:any):Observable<any>{
    return this.http.get<any>(`http://localhost:5000/api/res/${userId}`)
  }
  
  addRes(responses:any,totalScore:any):Observable<any>{
    console.log(responses,totalScore)
    return this.http.post<any>('http://localhost:5000/api/res',{responses,totalScore})
  }


  getResponsesByTestId(testId:any):Observable<any>{
    return this.http.get<any>(`http://localhost:5000/api/res/test/${testId}`)
  }
}
