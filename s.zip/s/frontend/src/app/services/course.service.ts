import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  http=inject(HttpClient)
  constructor() { }

  getCoursesByStudentId(ID:string):Observable<any>{
    console.log(ID)
    return this.http.get(`http://localhost:5000/api/course/${ID}`)
  }
}
