import { Component } from '@angular/core';
import { TestsService } from '../../../services/tests.service';
import { UserService } from '../../../services/user.service';
import { ResponsesService } from '../../../services/responses.service';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-test-performance',
  imports: [CommonModule],
  templateUrl: './test-performance.component.html',
  styleUrl: './test-performance.component.css'
})
export class TestPerformanceComponent {
  testId: string = '';
  students: any[] = [];
  

  constructor(
    private testsService: TestsService,
    private resService: ResponsesService,
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
  ) {}

  ngOnInit(): void {

    this.testId = this.activatedRoute.snapshot.paramMap.get('testId') || ''; 

    console.log(this.testId)
    this.resService.getResponsesByTestId(this.testId).subscribe(
      (responses) => {
        const studentPromises = responses.map((response: any) => {
          return this.userService.getStudentById(response.student_id).toPromise().then(student => ({
            id:student.id,
            name: student.name,
            score: response.score || 'Not Attempted', 
          }));
        });

        Promise.all(studentPromises).then(students => {
          this.students = students;
          console.log(this.students);
        }).catch(error => {
          console.error('Error fetching student names:', error);
        });
      },
      (error) => {
        console.error('Error fetching student responses:', error);
      }
    );

    console.log(this.students)
  }


  

}
