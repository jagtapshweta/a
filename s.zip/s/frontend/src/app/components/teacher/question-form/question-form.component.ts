import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { QuestionsService } from '../../../services/questions.service';

@Component({
  selector: 'app-question-form',
  imports:[
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './question-form.component.html',
  styleUrls: ['./question-form.component.css']
})
export class QuestionFormComponent {
  questionForm: FormGroup;
  imagePreview: string | ArrayBuffer | null = null;

  questionService=inject(QuestionsService)

  constructor(private fb: FormBuilder) {
    this.questionForm = this.fb.group({
      question:['',Validators.required],
      course_id: ['', Validators.required],
      options: ['', Validators.required],
      correct_options: ['', Validators.required],
      image: [null],
      math_expression: ['']
    });
  }

  onImageUpload(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => (this.imagePreview = reader.result);
      reader.readAsDataURL(file);
      this.questionForm.patchValue({ image: file });
    }
  }

  submitForm() {
    if (this.questionForm.valid) {
      const formData = this.questionForm.value;

      // Convert JSON strings to actual objects
      try {
        formData.options = JSON.parse(formData.options);
        formData.correct_options = JSON.parse(formData.correct_options);
      } catch (error) {
        alert("Invalid JSON format in options or correct options!");
        return;
      }
      this.questionService.addQuestion(formData).subscribe(
        (response) => {
          console.log('Success:', response);
          alert('Question added successfully!');
        },
        (error) => {
          console.error('Error:', error);
          alert('Failed to add question!');
        }
      );

    } else {
      alert('Please fill all required fields correctly.');
    }
  }
}

