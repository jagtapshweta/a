// create-test.component.ts
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TestsService } from '../../../services/tests.service'; 
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-test-form',
  imports:[CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent {
  testForm: FormGroup;

  constructor(private fb: FormBuilder, private testsService: TestsService) {
    this.testForm = this.fb.group({
      course_id: ['', Validators.required],
      title: ['', Validators.required],
      time_limit: [null, Validators.required],
      number_of_questions: [null, Validators.required],
      end_at: ['', Validators.required]
    });
  }

  submitForm() {
    if (this.testForm.valid) {
      const formData = this.testForm.value;
      console.log('Form Data:', formData);
      this.testsService.createTest(formData).subscribe(
        (response) => {
          console.log('Test Created:', response);
          alert('Test created successfully!');
        },
        (error) => {
          console.error('Error:', error);
          alert('An error occurred while creating the test.');
        }
      );
    } else {
      alert('Please fill in all fields correctly.');
    }
  }
}
