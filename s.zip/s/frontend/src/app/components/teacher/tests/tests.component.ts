import { Component, OnInit } from '@angular/core';
import { TestsService } from '../../../services/tests.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tests',
  imports:[
   CommonModule,
   ReactiveFormsModule 
  ],
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css']
})
export class TestsComponent implements OnInit {
  tests: any[] = [];  

  constructor(
    private testsService:TestsService,
    private userService:UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadAllTests()
  }

  loadAllTests() {
    this.testsService.getActiveTests().subscribe(
      (response) => {
        console.log(response)
        this.tests = response.filter(
          (test:any) =>
            this.userService.getUserId()==test.teacher_id
        ).sort((a: any, b: any) => new Date(a.end_at).getTime() - new Date(b.end_at).getTime());;
      },
      (error) => {
        console.error('Error fetching active tests:', error);
      }
    );
  }

 
  goToTestDetail(testId: number) {
     this.router.navigate(['/test-per', testId]);
  }
}
