import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { catchError } from 'rxjs';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  imports: [CommonModule, ReactiveFormsModule],
})
export class HomeComponent {
  userService = inject(UserService)

  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      userId: ['', [Validators.required, Validators.minLength(4)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  get userId() {
    return this.loginForm.get('userId');
  }

  get password() {
    return this.loginForm.get('password');
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.userService.login({
        id: this.loginForm.value.userId,
        password: this.loginForm.value.password,
        role: this.userService.getRole(this.loginForm.value.userId),
        name: ""
      })
        .pipe(
          catchError((err) => {
            console.error("Login failed:", err);
            alert("Login failed. Please try again.");
            throw err;
          })
        )
        .subscribe({
          next: (response) => {
            if (response && response.token) {
              console.log("Login successful! Token:", response.token);
              localStorage.setItem('token', response.token);
              localStorage.setItem('user', JSON.stringify(response.user));

              alert("Login Successful!");

              if (this.userService.getUserRole() == 'Student')
                this.router.navigate(['/dashboard']);

              if (this.userService.getUserRole() == "Teacher")
                this.router.navigate(['/teacher-dashboard']);
            }
          },
          error: (err) => {
            console.error("Error during login:", err);
            alert("An error occurred during login.");
          }
        });
    } else {
      alert("Please fill the form correctly.");
    }
  }


}
