import { Component, inject } from '@angular/core';
import {CommonModule } from '@angular/common';
import { UserService } from '../../services/user.service';
import { PastTestListComponent } from '../student/past-test-list/past-test-list.component';
import { ActiveTestListComponent } from '../student/active-test-list/active-test-list.component';
import { RouterOutlet } from '@angular/router';



@Component({
  selector: 'app-dashboard',
  standalone:true,
  imports: [
   CommonModule,
   PastTestListComponent,
   ActiveTestListComponent,
   RouterOutlet
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  activeSection: string = 'active-tests';

  userService = inject(UserService)
  
  username: string = this.userService.getUserName();

  setActiveSection(section: string) {
    this.activeSection = section;
  }
}
