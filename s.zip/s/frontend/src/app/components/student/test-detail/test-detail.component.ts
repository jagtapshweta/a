import { Component, OnInit, OnDestroy } from '@angular/core';
import { TestsService } from '../../../services/tests.service';  // Service to fetch test data
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { ResponsesService } from '../../../services/responses.service';

@Component({
  selector: 'app-test-detail',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './test-detail.component.html',
  styleUrls: ['./test-detail.component.css']
})
export class TestDetailComponent implements OnInit, OnDestroy {
  questionForm!: FormGroup;
  testId: string = '';
  testTitle = 'Sample MCQ Test';
  questions: any[] = [];
  timeLeft = 600; // 10 minutes
  minutes: number = 0;
  seconds: number = 0;
  timer: any;

  constructor(
    private fb: FormBuilder,
    private testService: TestsService,
    private userService: UserService,
    private resService: ResponsesService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.testId = this.route.snapshot.paramMap.get('testId') || ''; 
    this.initializeForm();  // ✅ Initialize form before fetching questions
    this.fetchQuestions();
    this.startTimer();
  }

  initializeForm() {
    this.questionForm = this.fb.group({});
  }

  getOptions(optionsObj: { [key: string]: string }): string[] {
    return Object.values(optionsObj);
  }

  fetchQuestions() {
    this.testService.getTestQuestions(this.testId).subscribe(data => {
      this.questions = data;

      let formControls: { [key: string]: FormControl } = {};
      this.questions.forEach(q => {
        formControls[q.id] = new FormControl('');
      });

      this.questionForm = this.fb.group(formControls);  // ✅ Update form after fetching questions
    });
  }

  startTimer() {
    this.timer = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
        this.minutes = Math.floor(this.timeLeft / 60);
        this.seconds = this.timeLeft % 60;
      } else {
        this.submitTest(); 
      }
    }, 1000);
  }

  getOptionKey(selectedOptionValue: string, options: { [key: string]: string }): string {
    for (const key in options) {
      if (options[key] === selectedOptionValue) {
        return key;  // Return the key (e.g., "A", "B", etc.) for the selected option value
      }
    }
    return '';  // Return an empty string if no match is found
  }
  

  submitTest() {
    clearInterval(this.timer);
  
    const formData = this.questionForm.value;
    const studentId = this.userService.getUserId();
    const submittedAt = new Date().toISOString();
    let totalScore = 0;
  
    const responses = this.questions.map((question) => {
      // Get selected option value
      const selectedOptionValue = formData[question.id] || null;
  
      // Map selected option value to its corresponding option key
      const selectedOptionKey = this.getOptionKey(selectedOptionValue, question.options);
  
      // Ensure `correct_options` is an array before parsing
      let correctOptionKeys: string[] = [];
      if (typeof question.correct_options === 'string') {
        try {
          correctOptionKeys = JSON.parse(question.correct_options); // Safely parse if it's a string
        } catch (error) {
          console.error(`Invalid JSON format for question ${question.id}:`, question.correct_options);
          correctOptionKeys = []; // Default empty array to prevent errors
        }
      } else if (Array.isArray(question.correct_options)) {
        correctOptionKeys = question.correct_options; // Already an array
      }
  
      const isCorrect = correctOptionKeys.includes(selectedOptionKey);  // Compare option keys
      if (isCorrect) totalScore++;
  
      return {
        test_id: this.testId,
        student_id: studentId,
        question_id: question.id,
        selected_option_key: selectedOptionKey, 
        score: isCorrect ? 1 : 0,
        submitted_at: submittedAt
      };
    });
  
    console.log(responses); 
  
    this.resService.addRes(responses, totalScore).subscribe(
      (response) => {
        console.log('Test submitted successfully:', response);
        alert(`Test submitted! Your score: ${totalScore}/${this.questions.length}`);
      },
      (error) => {
        console.error('Error submitting test:', error);
      }
    );
  }
  
  

  ngOnDestroy(): void {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
  
}
