import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveTestListComponent } from './active-test-list.component';

describe('ActiveTestListComponent', () => {
  let component: ActiveTestListComponent;
  let fixture: ComponentFixture<ActiveTestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActiveTestListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActiveTestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
