import { Component } from '@angular/core';
import { TestsService } from '../../../services/tests.service';
import { UserService } from '../../../services/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { CourseService } from '../../../services/course.service';
import { Router } from '@angular/router';
import { ResponsesService } from '../../../services/responses.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-active-test-list',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './active-test-list.component.html',
  styleUrl: './active-test-list.component.css'
})
export class ActiveTestListComponent {
  tests: any[] = [];  
  courses:any[]=[];
  attempt:any[]=[];

  constructor(
    private testsService:TestsService,
    private resService:ResponsesService,
    private userService:UserService,
    private courseService:CourseService,
    private router: Router
  ) {}

  ngOnInit(): void {
    console.log(this.userService.getUserId())

    forkJoin([
      this.resService.getTestsByUserId(this.userService.getUserId()),  // API call for attempts
      this.courseService.getCoursesByStudentId(this.userService.getUserId())  // API call for courses
    ]).subscribe(
      ([attemptResponse, coursesResponse]) => {
        // After both API responses are available, set the variables
        this.attempt = attemptResponse;
        this.courses = coursesResponse;

        console.log('Attempted Tests:', this.attempt);
        console.log('Courses:', this.courses);

        // Now load all tests
        this.loadAllTests();
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    );
  }

  loadAllTests() {
    this.testsService.getActiveTests().subscribe(
      (response) => {
        const currentTime = new Date().getTime(); // Current timestamp
        console.log('Current Time:', new Date(currentTime).toISOString()); // Log current time in UTC
    
        response.forEach((test: any) => {
          console.log('Test end_at:', test.end_at, 'Converted:', new Date(test.end_at).toISOString());
        });

      

    
        this.tests = response
          .filter((test: any) => {
            const testEndTime = new Date(test.end_at).getTime();
            console.log(`Comparing ${testEndTime} < ${currentTime}:`, testEndTime < currentTime);
            console.log(this.courses)

            const isTestAttempted = this.attempt.some(attempt => attempt.test_id === test.id);

            return testEndTime > currentTime && this.courses.some(course => course.course_id === test.course_id)&& !isTestAttempted ;
          })
          .sort((a: any, b: any) => new Date(a.end_at).getTime() - new Date(b.end_at).getTime());
    
        console.log('Filtered Tests:', this.tests);
      },
      (error) => {
        console.error('Error fetching active tests:', error);
      }
    );
  }
  

 
  goToTest(testId: string) {
    this.router.navigate(['/test', testId]);
  }
}
