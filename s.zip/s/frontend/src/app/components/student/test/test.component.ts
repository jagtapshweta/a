import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-test',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="test-container">
      <h2>{{ testTitle }}</h2>
      <div class="timer">Time Left: {{ minutes }}:{{ seconds | number: '2.0' }}</div>

      <div *ngFor="let question of testQuestions; let i = index" class="question">
        <p>{{ i + 1 }}. {{ question.text }}</p>
        <div *ngFor="let option of question.options">
          <label>
            <input type="radio" [name]="'question' + i" [value]="option" 
                   (change)="selectAnswer(i, option)" 
                   [checked]="selectedAnswers[i] === option" />
            {{ option }}
          </label>
        </div>
      </div>

      <button (click)="submitTest()" [disabled]="submitted">Submit</button>
      <p *ngIf="submitted">Test submitted successfully!</p>
    </div>
  `,
  styles: [`
    .test-container { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
    .question { margin-bottom: 20px; }
    .timer { font-weight: bold; color: red; margin-bottom: 10px; }
    button { padding: 10px 20px; font-size: 16px; background: blue; color: white; border: none; border-radius: 5px; cursor: pointer; }
    button:disabled { background: grey; cursor: not-allowed; }
  `]
})
export class TestComponent implements OnInit, OnDestroy {
  @Input() testTitle: string = 'Online Test';
  @Input() testQuestions: { text: string; options: string[] }[] = [];
  @Input() testDuration: number = 60; // in seconds

  selectedAnswers: { [key: number]: string } = {};
  timer: any;
  timeLeft: number=0;
  submitted: boolean = false;

  get minutes() { return Math.floor(this.timeLeft / 60); }
  get seconds() { return this.timeLeft % 60; }

  ngOnInit() {
    this.timeLeft = this.testDuration;
    this.startTimer();
  }

  startTimer() {
    this.timer = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      } else {
        this.submitTest(); // Auto-submit when time is up
      }
    }, 1000);
  }

  selectAnswer(index: number, option: string) {
    this.selectedAnswers[index] = option;
  }

  submitTest() {
    if (this.submitted) return;
    
    this.submitted = true;
    clearInterval(this.timer);
    
    console.log('Test Submitted:', this.selectedAnswers);
    alert('Test submitted successfully!');
  }

  ngOnDestroy() {
    clearInterval(this.timer); // Cleanup on component destroy
  }
}
