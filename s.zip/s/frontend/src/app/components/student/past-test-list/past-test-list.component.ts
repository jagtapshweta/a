// import { Component } from '@angular/core';
// import { TestsService } from '../../../services/tests.service';
// import { UserService } from '../../../services/user.service';
// import { CommonModule } from '@angular/common';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CourseService } from '../../../services/course.service';
// import { ResponsesService } from '../../../services/responses.service';
// import { forkJoin } from 'rxjs';

// @Component({
//   selector: 'app-past-test-list',
//   imports: [CommonModule,ReactiveFormsModule],
//   templateUrl: './past-test-list.component.html',
//   styleUrl: './past-test-list.component.css'
// })
// export class PastTestListComponent {
// tests: any[] = [];  
// courses:any[]=[];
// attempt:any[]=[];

//   constructor(
//     private testsService:TestsService,
//     private userService:UserService,
//     private resService:ResponsesService,
//     private courseService:CourseService
//   ) {}

//   ngOnInit(): void {
    
//     forkJoin([
//       this.resService.getTestsByUserId(this.userService.getUserId()),  
//       this.courseService.getCoursesByStudentId(this.userService.getUserId()) 
//     ]).subscribe(
//       ([attemptResponse, coursesResponse]) => {
  
//         this.attempt = attemptResponse;
//         this.courses = coursesResponse;

//         console.log('Attempted Tests:', this.attempt);
//         console.log('Courses:', this.courses);

//         // Now load all tests
//         this.loadAllTests();
//       },
//       (error) => {
//         console.error('Error fetching data:', error);
//       }
//     );
//   }

//   loadAllTests() {
//     this.testsService.getActiveTests().subscribe(
//       (response) => {
//         const currentTime = new Date().getTime(); // Current timestamp
//         console.log('Current Time:', new Date(currentTime).toISOString()); // Log current time in UTC
    
//         response.forEach((test: any) => {
//           console.log('Test end_at:', test.end_at, 'Converted:', new Date(test.end_at).toISOString());
//         });
    
//         this.tests = response
//           .filter((test: any) => {
//             const testEndTime = new Date(test.end_at).getTime();
//             console.log(`Comparing ${testEndTime} < ${currentTime}:`, testEndTime < currentTime);
//             console.log(this.courses)
//             const isTestAttempted = this.attempt.some(attempt => attempt.test_id === test.id);

//             return (testEndTime < currentTime||isTestAttempted) && this.courses.some(course => course.course_id === test.course_id);
//           })
//           .sort((a: any, b: any) => new Date(a.end_at).getTime() - new Date(b.end_at).getTime());
    
//         console.log('Filtered Tests:', this.tests);
//       },
//       (error) => {
//         console.error('Error fetching active tests:', error);
//       }
//     );
    
//   }
  

 
//   goToTestDetail(testId: number) {
 
//   }
// }



import { Component } from '@angular/core';
import { TestsService } from '../../../services/tests.service';
import { UserService } from '../../../services/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { CourseService } from '../../../services/course.service';
import { ResponsesService } from '../../../services/responses.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-past-test-list',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './past-test-list.component.html',
  styleUrl: './past-test-list.component.css'
})
export class PastTestListComponent {
  tests: any[] = [];  
  courses: any[] = [];
  attempt: any[] = [];

  constructor(
    private testsService: TestsService,
    private userService: UserService,
    private resService: ResponsesService,
    private courseService: CourseService
  ) {}

  ngOnInit(): void {
    // Wait for both API calls to complete using forkJoin
    forkJoin([
      this.resService.getTestsByUserId(this.userService.getUserId()),  // Get attempted tests by user
      this.courseService.getCoursesByStudentId(this.userService.getUserId())  // Get courses for the student
    ]).subscribe(
      ([attemptResponse, coursesResponse]) => {
        this.attempt = attemptResponse;
        this.courses = coursesResponse;

        console.log('Attempted Tests:', this.attempt);
        console.log('Courses:', this.courses);

        // Now load all tests
        this.loadAllTests();
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    );
  }

  loadAllTests() {
    this.testsService.getActiveTests().subscribe(
      (response) => {
        const currentTime = new Date().getTime(); // Current timestamp
        console.log('Current Time:', new Date(currentTime).toISOString()); // Log current time in UTC

        response.forEach((test: any) => {
          console.log('Test end_at:', test.end_at, 'Converted:', new Date(test.end_at).toISOString());
        });

        // Map through the tests and add the score or 'Not Attempted' if not attempted
        this.tests = response
          .filter((test: any) => {
            const testEndTime = new Date(test.end_at).getTime();
            const isTestAttempted = this.attempt.some(attempt => attempt.test_id === test.id);

            // Filter past tests, those that have been attempted or are in the current user's courses
            return (testEndTime < currentTime || isTestAttempted) && this.courses.some(course => course.course_id === test.course_id);
          })
          .map((test: any) => {
            // Add score or 'Not Attempted' if the test has not been attempted
            const isTestAttempted = this.attempt.some(attempt => attempt.test_id === test.id);
            const score = isTestAttempted ? this.attempt.find(attempt => attempt.test_id === test.id).score : 0;
            test.score = isTestAttempted ? score : 'Not Attempted';
            return test;
          })
          .sort((a: any, b: any) => new Date(a.end_at).getTime() - new Date(b.end_at).getTime());

        console.log('Filtered Tests with Scores:', this.tests);
      },
      (error) => {
        console.error('Error fetching active tests:', error);
      }
    );
  }

  goToTestDetail(testId: number) {
    // Navigate to the test details (you can update the routing as needed)
  }
}
