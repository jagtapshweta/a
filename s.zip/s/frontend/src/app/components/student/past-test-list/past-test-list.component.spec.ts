import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PastTestListComponent } from './past-test-list.component';

describe('PastTestListComponent', () => {
  let component: PastTestListComponent;
  let fixture: ComponentFixture<PastTestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PastTestListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PastTestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
