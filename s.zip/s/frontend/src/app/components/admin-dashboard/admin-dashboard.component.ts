import { Component, inject } from '@angular/core';
import {CommonModule } from '@angular/common';
import { QuestionFormComponent } from '../teacher/question-form/question-form.component';
import { UserService } from '../../services/user.service';
import { TestFormComponent } from '../teacher/test-form/test-form.component';
import { TestsComponent } from '../teacher/tests/tests.component';


@Component({
  selector: 'app-admin-dashboard',
  standalone:true,
  imports: [
   CommonModule,
   QuestionFormComponent,
   TestFormComponent,
   TestsComponent
  ],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent {
  activeSection: string = 'question-form';

  userService = inject(UserService)
  
  username: string = this.userService.getUserName();

  setActiveSection(section: string) {
    this.activeSection = section;
  }
}
