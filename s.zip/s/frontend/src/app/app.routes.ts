import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { DashboardComponent } from './components/s-d/dashboard.component';
import { TestDetailComponent } from './components/student/test-detail/test-detail.component';
import { TestPerformanceComponent } from './components/teacher/test-performance/test-performance.component';

export const routes: Routes = [
    {
        path:'',
        pathMatch:'full',
        component:HomeComponent
    },
    {
        path:'dashboard',
        component:DashboardComponent
    },
    {
        path:'teacher-dashboard',
        component:AdminDashboardComponent
    },
    {
        path:'test/:testId',
        component:TestDetailComponent
    },

    {
        path:'test-per/:testId',
        component:TestPerformanceComponent
    }

];
