export type Test ={
    title:string;
    id: string;
    course_id: string;
    teacher_id:string;
    end_at: string; 
    time_limit: number; 
    number_of_questions:number;
    created_at:string;
  }
  