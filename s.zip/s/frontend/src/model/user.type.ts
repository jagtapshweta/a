export type User = {
    id: string;
    password: string;
    role: string;
    name:string;
};
  