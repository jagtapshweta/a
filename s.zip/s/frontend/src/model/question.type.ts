export type Question={
    course_id: string;      
    question: string;         
    options: { [key: string]: string }; 
    correct_options: string[]; 
    math_expression: string; 
    image: string | null;     
}
  