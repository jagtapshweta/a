-- Create the examportal database
create database examportal;

-- Use the examportal database
use examportal;

-- Table: courses
create table courses (
    id varchar(200) primary key, 
    title varchar(100), 
    dept_name varchar(50), 
    credits int
);

-- Table: questions
create table questions (
    id varchar(200) primary key, 
    course_id varchar(200), 
    options json, 
    correct_options json, 
    image varchar(255), 
    math_expression text, 
    question text
);

-- Table: takes
create table takes (
    id varchar(200) primary key, 
    course_id varchar(200) primary key, 
    semester varchar(10) primary key, 
    year int primary key
);

-- Table: test_questions
create table test_questions (
    test_id varchar(200) primary key, 
    question_id varchar(200) primary key
);

-- Table: test_responses
create table test_responses (
    id int auto_increment primary key, 
    test_id varchar(200), 
    student_id varchar(200), 
    question_id varchar(200), 
    options json, 
    score int, 
    submitted_at timestamp
);

-- Table: tests
create table tests (
    id varchar(200) primary key, 
    course_id varchar(200), 
    teacher_id varchar(200), 
    time_limit int, 
    created_at timestamp, 
    number_of_questions int, 
    end_at timestamp, 
    title text
);

-- Table: users
create table users (
    id varchar(200) primary key, 
    name varchar(200), 
    role enum('Student','Teacher'), 
    password varchar(200), 
    created_at timestamp
);