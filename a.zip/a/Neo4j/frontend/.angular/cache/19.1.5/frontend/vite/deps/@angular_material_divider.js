import {
  MatDivider,
  MatDividerModule
} from "./chunk-3TYWR5YN.js";
import "./chunk-E3EDDWIT.js";
import "./chunk-UCEVDRF5.js";
import "./chunk-3KS3D65X.js";
import "./chunk-556KATUP.js";
import "./chunk-IYE42FHU.js";
import "./chunk-WSXI74FV.js";
import "./chunk-LBBSG2YE.js";
import "./chunk-NGNUV6BG.js";
export {
  MatDivider,
  MatDividerModule
};
