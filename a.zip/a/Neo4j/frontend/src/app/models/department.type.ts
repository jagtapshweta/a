export type Department = {
    id:string;
    dept_name:string;
    building:string;
    budget:number;
};
  