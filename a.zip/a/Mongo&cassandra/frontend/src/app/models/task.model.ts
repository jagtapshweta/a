export interface Task {
    _id: string;
    text: string;
    completed: boolean;
}
  